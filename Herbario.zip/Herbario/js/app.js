document.addEventListener('DOMContentLoaded', () => {
  // Ordenamos la data de data.js por nombre común
  const dataOrdenada = [...PLANTAS].sort((a, b) =>
    a.nombreComun.localeCompare(b.nombreComun, 'es')
  );

  // Llenamos el contador del header
  document.getElementById('total-count').textContent = PLANTAS.length;

  // Iniciamos los filtros
  iniciarFiltros();

  // Render inicial
  renderizarGrid(dataOrdenada);

  // Configuración del botón de limpieza
  document.getElementById('reset-btn').onclick = resetearFiltros;
});
