const filtros = { busqueda: '', familia: '', genero: '', estado: '' };

function aplicarFiltros() {
  const { busqueda, familia, genero, estado } = filtros;

  const result = PLANTAS.filter(p => {
    if (busqueda) {
      const q = busqueda.toLowerCase().trim();
      const match = [p.nombreComun, p.especie, p.familia, p.recolector].some(c =>
        (c || '').toLowerCase().includes(q)
      );
      if (!match) return false;
    }

    if (familia && p.familia !== familia) return false;
    if (genero && p.genero !== genero) return false;
    if (estado && p.estadoMX !== estado) return false;

    return true;
  });

  // Mantenemos el orden alfabético incluso en los resultados filtrados
  result.sort((a, b) => a.nombreComun.localeCompare(b.nombreComun, 'es'));
  
  renderizarGrid(result);
}

function iniciarFiltros() {
  const searchInput = document.getElementById('search-input');
  
  searchInput.addEventListener('input', (e) => {
    filtros.busqueda = e.target.value;
    aplicarFiltros();
  });

  document.getElementById('filter-familia').addEventListener('change', e => {
    filtros.familia = e.target.value;
    aplicarFiltros();
  });

  document.getElementById('filter-genero').addEventListener('change', e => {
    filtros.genero = e.target.value;
    aplicarFiltros();
  });

  document.getElementById('filter-estado').addEventListener('change', e => {
    filtros.estado = e.target.value;
    aplicarFiltros();
  });

  poblarSelect('filter-familia', 'familia');
  poblarSelect('filter-genero', 'genero');
  poblarSelect('filter-estado', 'estadoMX');
}

function poblarSelect(id, campo) {
  const select = document.getElementById(id);
  const valores = [...new Set(PLANTAS.map(p => p[campo]))].sort();
  valores.forEach(v => {
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    select.appendChild(opt);
  });
}

function resetearFiltros() {
  filtros.busqueda = '';
  filtros.familia = '';
  filtros.genero = '';
  filtros.estado = '';
  
  document.getElementById('search-input').value = '';
  ['filter-familia', 'filter-genero', 'filter-estado'].forEach(id => {
    document.getElementById(id).value = '';
  });

  const inicio = [...PLANTAS].sort((a, b) => a.nombreComun.localeCompare(b.nombreComun, 'es'));
  renderizarGrid(inicio);
}
