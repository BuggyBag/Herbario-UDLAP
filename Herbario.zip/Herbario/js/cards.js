function crearTarjeta(planta) {
  const wrapper = document.createElement('div');
  wrapper.className = 'card-wrapper';
  
  wrapper.innerHTML = `
    <div class="card-inner">
      <div class="card-front">
        <div class="card-img">
          <img src="${planta.imagen}" alt="${planta.nombreComun}">
          <div class="card-overlay">
            <span class="scientific-name">${planta.especie}</span>
            <p style="font-size: 0.7rem; margin-top: 10px;">CLICK PARA DETALLES</p>
          </div>
        </div>
        <div class="card-foot">${planta.nombreComun}</div>
      </div>
      <div class="card-back">
        <h3 class="back-title">${planta.nombreComun}</h3>
        <p><em>${planta.especie}</em></p>
        <hr style="border: 0; border-top: 1px solid #eee; margin: 15px 0;">
        <div class="back-data">
          <p><strong>Familia:</strong> ${planta.familia}</p>
          <p><strong>Localidad:</strong> ${planta.lugarRecolecta}, ${planta.estadoMX}</p>
          <p><strong>Recolector:</strong> ${planta.recolector}</p>
          <p><strong>Catálogo:</strong> ${planta.numCatalogo}</p>
        </div>
      </div>
    </div>
  `;

  wrapper.addEventListener('click', () => wrapper.classList.toggle('flipped'));
  return wrapper;
}

function renderizarGrid(lista) {
  const grid = document.getElementById('cards-grid');
  const emptyState = document.getElementById('empty-state');
  const resultsInfo = document.getElementById('results-info');

  grid.innerHTML = '';
  
  if (lista.length === 0) {
    emptyState.style.display = 'block';
    resultsInfo.textContent = '';
    return;
  }

  emptyState.style.display = 'none';
  resultsInfo.textContent = `${lista.length} muestras encontradas`;

  const fragment = document.createDocumentFragment();
  lista.forEach(p => fragment.appendChild(crearTarjeta(p)));
  grid.appendChild(fragment);
}
